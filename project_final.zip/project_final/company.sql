-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2021 at 12:22 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-med`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `email`, `password`, `contact_no`, `address`, `registration_date`, `status`) VALUES
(1, 'weut', 'x@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', '01832455897', '', '2021-09-01 19:03:36', 1),
(2, 'weut', 'x@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', '01832455897', '', '2021-09-01 19:16:20', 1),
(3, 'Matlab Dakkhin Chandpur', 'acbd@gmail.com', '37693cfc748049e45d87b8c7d8b9aacd', '01631697506', '', '2021-09-01 19:16:53', 1),
(4, 'Matlab Dakkhin Chandpur', 'acbd@gmail.com', '37693cfc748049e45d87b8c7d8b9aacd', '01631697506', '', '2021-09-01 19:17:43', 1),
(5, 'Matlab Dakkhin Chandpur', 'acbd@gmail.com', '37693cfc748049e45d87b8c7d8b9aacd', '01631697506', '', '2021-09-01 19:20:45', 1),
(6, 'Matlab Dakkhin Chandpur', 'acbd@gmail.com', '37693cfc748049e45d87b8c7d8b9aacd', '01631697506', '', '2021-09-01 19:21:38', 1),
(7, 'Matlab Dakkhin Chandpur', 'acbd@gmail.com', '37693cfc748049e45d87b8c7d8b9aacd', '01631697506', '', '2021-09-01 19:38:37', 1),
(8, 'Matlab Dakkhin Chandpur', 'bcd@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', '537,maddho kaladi,matlab dakkhin chandpur.', '', '2021-09-01 19:39:13', 1),
(9, 'Matlab Dakkhin Chandpur', 'rakibul@gmail.com', '202cb962ac59075b964b07152d234b70', '01631697506', '', '2021-09-01 19:42:19', 1),
(10, 'Matlab Dakkhin Chandpur', 'k@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '0134567889', '', '2021-09-01 19:48:45', 1),
(11, 'Matlab Dakkhin Chandpur', 'k@gmail.com', 'cfcd208495d565ef66e7dff9f98764da', '09128653423', '', '2021-09-01 20:00:41', 1),
(12, 'Matlab Dakkhin Chandpur', 'w@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', '01832455897', '', '2021-09-01 20:15:16', 1),
(13, 'Matlab Dakkhin Chandpur', 'islam@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', '01832455897', NULL, '2021-09-01 20:35:46', 1),
(14, 'Matlab Dakkhin Chandpur', 'e@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '01777473208', NULL, '2021-09-01 20:45:29', 1),
(15, 'Matlab Dakkhin Chandpur', 'pp@gmail.com', '6512bd43d9caa6e02c990b0a82652dca', '01631697506', NULL, '2021-09-07 06:01:02', 1),
(16, 'Matlab Dakkhin Chandpur', 'altabrakib7@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '01777473208', '537,maddho kaladi,matlab dakkhin chandpur.', '2021-09-21 15:51:22', 1),
(17, 'medicla', 'altabrakib777@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '09128653423', '537,maddho kaladi,matlab dakkhin chandpur.', '2021-09-26 09:21:31', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
