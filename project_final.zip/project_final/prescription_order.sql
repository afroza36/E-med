-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2021 at 12:22 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-med`
--

-- --------------------------------------------------------

--
-- Table structure for table `prescription_order`
--

CREATE TABLE `prescription_order` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `amount` decimal(10,0) NOT NULL DEFAULT 0,
  `hospital` varchar(255) NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `disease_type` varchar(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription_order`
--

INSERT INTO `prescription_order` (`id`, `company_id`, `prescription_id`, `quantity`, `amount`, `hospital`, `doctor`, `disease_type`, `payment_method`, `order_status`, `order_date`) VALUES
(2, 16, 35, 1, '2', 'Sirajul islam medical college', 'Nazmul islam', 'Deadly Disease', 'bkash', 'Pending', '2021-09-21 16:25:09'),
(3, 16, 35, 1, '2', 'Sirajul islam medical college', 'Nazmul islam', 'Deadly Disease', 'Nagad', 'Pending', '2021-09-21 16:25:27'),
(4, 16, 35, 1, '2', 'Sirajul islam medical college', 'Nazmul islam', 'Deadly Disease', 'Cash on Delivery', 'Pending', '2021-09-21 16:48:22'),
(5, 16, 35, 1, '2', 'Sirajul islam medical college', 'Nazmul islam', 'Deadly Disease', 'bkash', 'Pending', '2021-09-26 08:02:57'),
(6, 16, 35, 1, '50', 'Sirajul islam medical college', 'Nazmul islam', 'Deadly Disease', 'Nagad', 'Pending', '2021-09-26 08:23:49'),
(7, 17, 35, 1, '50', 'Sirajul islam medical college', 'Nazmul islam', 'Deadly Disease', 'bkash', 'Pending', '2021-09-26 09:22:02'),
(8, 16, 35, 1, '50', 'Sirajul islam medical college', 'Nazmul islam', 'Deadly Disease', 'bkash', 'Pending', '2021-09-26 10:19:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prescription_order`
--
ALTER TABLE `prescription_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKimage_orde420554` (`company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prescription_order`
--
ALTER TABLE `prescription_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `prescription_order`
--
ALTER TABLE `prescription_order`
  ADD CONSTRAINT `FKimage_orde420554` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
